<?php
/**
 * Plugin Name: Elementor Page Text Replacer
 * Description: Replace text inside one specific Elementor page only.
 * Version: 1.0
 */

if (!defined('ABSPATH')) exit;

add_action('admin_menu', function () {
    add_management_page(
        'Elementor Page Text Replacer',
        'Elementor Text Replacer',
        'manage_options',
        'elementor-page-text-replacer',
        'ept_replacer_page'
    );
});

function ept_replace_recursive($data, $search, $replace, &$count) {
    if (is_array($data)) {
        foreach ($data as $key => $value) {
            $data[$key] = ept_replace_recursive($value, $search, $replace, $count);
        }
        return $data;
    }

    if (is_string($data)) {
        $new = str_replace($search, $replace, $data, $local_count);
        $count += $local_count;
        return $new;
    }

    return $data;
}

function ept_replacer_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    $message = '';

    if (isset($_POST['ept_submit'])) {
        check_admin_referer('ept_replace_action');

        $page_id = absint($_POST['page_id']);
        $search = sanitize_text_field($_POST['search_text']);
        $replace = sanitize_text_field($_POST['replace_text']);
        $dry_run = isset($_POST['dry_run']);

        $data = get_post_meta($page_id, '_elementor_data', true);

        if (!$page_id || !$search || !$data) {
            $message = '<div class="notice notice-error"><p>Page ID, search text, or Elementor data is missing.</p></div>';
        } else {
            $decoded = json_decode($data, true);

            if (!is_array($decoded)) {
                $message = '<div class="notice notice-error"><p>Could not read Elementor JSON data.</p></div>';
            } else {
                $count = 0;
                $new_data = ept_replace_recursive($decoded, $search, $replace, $count);

                if ($dry_run) {
                    $message = '<div class="notice notice-info"><p>Dry run: found ' . esc_html($count) . ' replacement(s). No changes made.</p></div>';
                } else {
                    update_post_meta($page_id, '_elementor_data', wp_slash(wp_json_encode($new_data)));
                    update_post_meta($page_id, '_elementor_css', '');

                    if (class_exists('\Elementor\Plugin')) {
                        \Elementor\Plugin::$instance->files_manager->clear_cache();
                    }

                    $message = '<div class="notice notice-success"><p>Done. Replaced ' . esc_html($count) . ' item(s) on page ID ' . esc_html($page_id) . '.</p></div>';
                }
            }
        }
    }

    ?>
    <div class="wrap">
        <h1>Elementor Page Text Replacer</h1>
        <?php echo $message; ?>

        <form method="post">
            <?php wp_nonce_field('ept_replace_action'); ?>

            <table class="form-table">
                <tr>
                    <th><label for="page_id">Page ID</label></th>
                    <td><input type="number" name="page_id" id="page_id" class="regular-text" required></td>
                </tr>

                <tr>
                    <th><label for="search_text">Find Text</label></th>
                    <td><input type="text" name="search_text" id="search_text" class="regular-text" required></td>
                </tr>

                <tr>
                    <th><label for="replace_text">Replace With</label></th>
                    <td><input type="text" name="replace_text" id="replace_text" class="regular-text" required></td>
                </tr>

                <tr>
                    <th>Dry Run</th>
                    <td>
                        <label>
                            <input type="checkbox" name="dry_run" checked>
                            Check first without changing anything
                        </label>
                    </td>
                </tr>
            </table>

            <p>
                <button type="submit" name="ept_submit" class="button button-primary">
                    Run Replacement
                </button>
            </p>
        </form>
    </div>
    <?php
}